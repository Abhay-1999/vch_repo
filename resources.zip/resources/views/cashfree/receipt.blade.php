<!DOCTYPE html>
<html>
<head>
    <title>Receipt</title>
</head>
<body>
    <h2>Thank you for your payment!</h2>
    <p>Order ID: {{ $orderId }}</p>
</body>
</html>
